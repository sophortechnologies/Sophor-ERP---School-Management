export { SchoolConfigForm } from "./SchoolConfigForm";
