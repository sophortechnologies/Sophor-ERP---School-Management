export { SchoolConfigPage } from "./SchoolConfigPage";
