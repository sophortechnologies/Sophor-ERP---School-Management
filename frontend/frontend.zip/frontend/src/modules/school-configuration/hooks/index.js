export { useSchoolConfig } from "./useSchoolConfig";
