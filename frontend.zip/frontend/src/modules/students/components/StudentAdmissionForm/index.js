export { default } from "./StudentAdmissionForm";
