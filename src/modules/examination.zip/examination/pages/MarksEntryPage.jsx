import React, { useState, useEffect, useMemo, useCallback } from "react";
import examinationApi from "../api/examination.api";
import api from "@/api/axios";
import "./MarksEntryPage.css";

export const MarksEntryPage = () => {
  const [exams, setExams] = useState([]);
  const [classes, setClasses] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [students, setStudents] = useState([]);
  const [gradeScales, setGradeScales] = useState([]);

  const [selectedExamId, setSelectedExamId] = useState("");
  const [selectedClassId, setSelectedClassId] = useState("");
  const [selectedSubjectId, setSelectedSubjectId] = useState("");
  const [totalMarks, setTotalMarks] = useState(100);

  const [marksState, setMarksState] = useState({});
  const [remarksState, setRemarksState] = useState({});
  const [loadingSheet, setLoadingSheet] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [feedback, setFeedback] = useState({ type: "", text: "" });

  // Load prerequisites
  useEffect(() => {
    Promise.allSettled([
      examinationApi.getExams(),
      api.get("/classes"),
      api.get("/subjects"),
      api.get("/students"),
      examinationApi.getGradeScales(),
    ]).then(([examsRes, classesRes, subjectsRes, studentsRes, scalesRes]) => {
      if (examsRes.status === "fulfilled")
        setExams(Array.isArray(examsRes.value) ? examsRes.value : []);
      if (classesRes.status === "fulfilled") {
        const d = classesRes.value.data?.data || classesRes.value.data || [];
        setClasses(Array.isArray(d) ? d : []);
      }
      if (subjectsRes.status === "fulfilled") {
        const d = subjectsRes.value.data?.data || subjectsRes.value.data || [];
        setSubjects(Array.isArray(d) ? d : []);
      }
      if (studentsRes.status === "fulfilled") {
        const d = studentsRes.value.data?.data || studentsRes.value.data || [];
        setStudents(Array.isArray(d) ? d : []);
      }
      if (scalesRes.status === "fulfilled") {
        setGradeScales(Array.isArray(scalesRes.value) ? scalesRes.value : []);
      }
    });
  }, []);

  // Filter students enrolled in the selected class
  const classStudents = useMemo(() => {
    if (!selectedClassId) return [];
    const targetCid = Number(selectedClassId);
    return students.filter((s) => {
      const cid = Number(
        s.classId || s.currentClassId || s.class?.id || s.enrollment?.classId,
      );
      return cid === targetCid;
    });
  }, [students, selectedClassId]);

  // Load existing mark records for the selected combination
  const loadExistingMarks = useCallback(async () => {
    if (!selectedExamId || !selectedClassId || !selectedSubjectId) {
      setMarksState({});
      setRemarksState({});
      return;
    }

    setLoadingSheet(true);
    setFeedback({ type: "", text: "" });

    try {
      const records = await examinationApi.getMarks({
        examId: selectedExamId,
        classId: selectedClassId,
        subjectId: selectedSubjectId,
      });

      const markMap = {};
      const remarkMap = {};

      records.forEach((r) => {
        const sid = Number(r.studentId || r.student?.id);
        if (sid) {
          markMap[sid] =
            r.marksObtained !== undefined && r.marksObtained !== null
              ? String(r.marksObtained)
              : "";
          remarkMap[sid] = r.remarks || "";
        }
      });

      setMarksState(markMap);
      setRemarksState(remarkMap);
    } catch {
      setFeedback({
        type: "error",
        text: "Failed to load marks for selected criteria.",
      });
    } finally {
      setLoadingSheet(false);
    }
  }, [selectedExamId, selectedClassId, selectedSubjectId]);

  useEffect(() => {
    loadExistingMarks();
  }, [loadExistingMarks]);

  const getStudentFullName = (s) =>
    s.fullName ||
    (s.firstName ? `${s.firstName} ${s.lastName || ""}`.trim() : null) ||
    s.user?.fullName ||
    (s.user?.firstName
      ? `${s.user.firstName} ${s.user.lastName || ""}`.trim()
      : null) ||
    `Student #${s.id}`;

  const calculateGradeFromScale = (score) => {
    const num = Number(score);
    if (isNaN(num)) return { grade: "—", gpa: 0 };
    const pct = (num / totalMarks) * 100;

    if (gradeScales.length > 0) {
      const match = gradeScales.find(
        (gs) =>
          pct >= Number(gs.minPercentage || gs.min) &&
          pct <= Number(gs.maxPercentage || gs.max),
      );
      if (match)
        return {
          grade: match.grade || match.name,
          gpa: Number(match.gradePoint || match.gpa || 0),
        };
    }

    // Standard fallback scale
    if (pct >= 90) return { grade: "A+", gpa: 4.0 };
    if (pct >= 80) return { grade: "A", gpa: 3.75 };
    if (pct >= 75) return { grade: "B+", gpa: 3.5 };
    if (pct >= 65) return { grade: "B", gpa: 3.0 };
    if (pct >= 55) return { grade: "C+", gpa: 2.5 };
    if (pct >= 50) return { grade: "C", gpa: 2.0 };
    if (pct >= 40) return { grade: "D", gpa: 1.0 };
    return { grade: "F", gpa: 0.0 };
  };

  const handleScoreChange = (studentId, val) => {
    const num = Number(val);
    if (val !== "" && (num < 0 || num > totalMarks)) return;
    setMarksState((prev) => ({ ...prev, [studentId]: val }));
  };

  const handleRemarkChange = (studentId, val) => {
    setRemarksState((prev) => ({ ...prev, [studentId]: val }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFeedback({ type: "", text: "" });

    const entries = classStudents
      .filter((s) => marksState[s.id] !== undefined && marksState[s.id] !== "")
      .map((s) => ({
        studentId: Number(s.id),
        marksObtained: Number(marksState[s.id]),
        totalMarks: Number(totalMarks),
        remarks: remarksState[s.id] || "",
      }));

    if (entries.length === 0) {
      setFeedback({
        type: "error",
        text: "Please enter marks for at least one student.",
      });
      return;
    }

    setSubmitting(true);
    try {
      await examinationApi.submitBatchMarks({
        examId: selectedExamId,
        classId: selectedClassId,
        subjectId: selectedSubjectId,
        marks: entries,
      });

      setFeedback({
        type: "success",
        text: "Marks successfully submitted and saved.",
      });
      await loadExistingMarks();
    } catch (err) {
      const msg = err.response?.data?.message;
      setFeedback({
        type: "error",
        text: Array.isArray(msg)
          ? msg.join(", ")
          : msg || "Failed to submit marks.",
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="marks-entry-container">
      <div className="marks-entry-header">
        <h1>Examination Marks Entry</h1>
        <p>
          Record exam evaluations and auto-grade against configured grading
          boundaries.
        </p>
      </div>

      <div className="marks-entry-content">
        {feedback.text && (
          <div
            className={
              feedback.type === "success"
                ? "marks-banner-success"
                : "marks-banner-error"
            }
          >
            {feedback.text}
          </div>
        )}

        {/* Selection Strip */}
        <div className="marks-entry-card">
          <div className="marks-filter-row">
            <div className="marks-field">
              <label>Examination *</label>
              <select
                value={selectedExamId}
                onChange={(e) => setSelectedExamId(e.target.value)}
              >
                <option value="">-- Select Exam --</option>
                {exams.map((ex) => (
                  <option key={ex.id} value={ex.id}>
                    {ex.name} ({ex.term || "Term"})
                  </option>
                ))}
              </select>
            </div>

            <div className="marks-field">
              <label>Class / Grade *</label>
              <select
                value={selectedClassId}
                onChange={(e) => setSelectedClassId(e.target.value)}
              >
                <option value="">-- Select Class --</option>
                {classes.map((cls) => (
                  <option key={cls.id} value={cls.id}>
                    {cls.name || `Class #${cls.id}`}
                  </option>
                ))}
              </select>
            </div>

            <div className="marks-field">
              <label>Subject *</label>
              <select
                value={selectedSubjectId}
                onChange={(e) => setSelectedSubjectId(e.target.value)}
              >
                <option value="">-- Select Subject --</option>
                {subjects.map((sub) => (
                  <option key={sub.id} value={sub.id}>
                    {sub.name} ({sub.code || "SUB"})
                  </option>
                ))}
              </select>
            </div>

            <div className="marks-field">
              <label>Total Marks</label>
              <input
                type="number"
                min="1"
                value={totalMarks}
                onChange={(e) => setTotalMarks(Number(e.target.value) || 100)}
              />
            </div>
          </div>
        </div>

        {/* Grade Sheet Table */}
        <div className="marks-entry-card">
          <div className="marks-card-title-bar">
            <span>Score Sheet ({classStudents.length} Students)</span>
            {classStudents.length > 0 && selectedSubjectId && (
              <button
                type="button"
                onClick={handleSubmit}
                disabled={submitting || loadingSheet}
                className="marks-btn-submit"
              >
                {submitting ? "Saving..." : "Save Marks"}
              </button>
            )}
          </div>

          {!selectedExamId || !selectedClassId || !selectedSubjectId ? (
            <div className="marks-empty-state">
              Select an Examination, Class, and Subject above to populate the
              student score sheet.
            </div>
          ) : loadingSheet ? (
            <div className="marks-empty-state">
              Loading student evaluations...
            </div>
          ) : classStudents.length === 0 ? (
            <div className="marks-empty-state">
              No students found enrolled in the selected class.
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              <table className="marks-entry-table">
                <thead>
                  <tr>
                    <th>Roll #</th>
                    <th>Student Name</th>
                    <th>Marks Obtained (/{totalMarks})</th>
                    <th>Percentage</th>
                    <th>Grade</th>
                    <th>Remarks</th>
                  </tr>
                </thead>
                <tbody>
                  {classStudents.map((st) => {
                    const currentScore = marksState[st.id] || "";
                    const percentage =
                      currentScore !== ""
                        ? ((Number(currentScore) / totalMarks) * 100).toFixed(1)
                        : null;
                    const gradeDetail =
                      percentage !== null
                        ? calculateGradeFromScale(currentScore)
                        : null;

                    return (
                      <tr key={st.id}>
                        <td>
                          <strong>#{st.rollNumber || st.id}</strong>
                        </td>
                        <td>
                          <strong>{getStudentFullName(st)}</strong>
                        </td>
                        <td>
                          <input
                            type="number"
                            min="0"
                            max={totalMarks}
                            step="0.5"
                            placeholder="Score"
                            className="marks-input-cell"
                            value={currentScore}
                            onChange={(e) =>
                              handleScoreChange(st.id, e.target.value)
                            }
                          />
                        </td>
                        <td>{percentage !== null ? `${percentage}%` : "—"}</td>
                        <td>
                          {gradeDetail ? (
                            <span className="marks-grade-badge">
                              {gradeDetail.grade}
                            </span>
                          ) : (
                            "—"
                          )}
                        </td>
                        <td>
                          <input
                            type="text"
                            placeholder="Optional remark"
                            className="marks-input-cell"
                            value={remarksState[st.id] || ""}
                            onChange={(e) =>
                              handleRemarkChange(st.id, e.target.value)
                            }
                          />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>

              <div className="marks-footer-actions">
                <button
                  type="submit"
                  disabled={submitting}
                  className="marks-btn-submit"
                >
                  {submitting ? "Saving..." : "Save Marks"}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default MarksEntryPage;
